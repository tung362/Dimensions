package net.minecraft.src;

public class BiomeGenRiver extends BiomeGenBase
{
    public BiomeGenRiver(int par1)
    {
        super(par1);
        this.spawnableCreatureList.clear();
    }
}
